<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-12 p-2">
            <center>
                <h2 style="text-transform: uppercase">Export Invoice Reports</h2>
                <hr />
            </center>
        </div>
    </div>
    <form method="POST" enctype="multipart/form-data" route="<?php echo e(route('processInvoices')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-6 d-flex">
                <div class="form-group col-4 p-2">
                    <label>Start Date</label>
                    <select class="form-select" name="start_day">
                        <option>Select Date</option>
                        <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-4 p-2">
                    <label>Start Month</label>
                    <select class="form-select" name="start_month">
                        <option>Select Month</option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-4 p-2">
                    <label>Start Year</label>
                    <select class="form-select" name="start_year">
                        <option>Select Year</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="col-6 d-flex">
                <div class="form-group col-4 p-2">
                    <label>End Date</label>
                    <select class="form-select" name="end_day">
                        <option>Select Date</option>
                        <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-4 p-2">
                    <label>End Month</label>
                    <select class="form-select" name="end_month">
                        <option>Select Month</option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($month); ?>"><?php echo e($month); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-4 p-2">
                    <label>End Year</label>
                    <select class="form-select" name="end_year">
                        <option>Select Year</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>"><?php echo e($year); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-6">
                <label for="name">Document Name</label>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Document Name"
                class="form-control">
            </div>
            <div class="col-6">
                <label for="type">Treatment Scheme</label>
                <select name="scheme" id="scheme" class="form-select">
                    <option>Select Treatment Scheme</option>
                    <option value="1">Resolution</option>
                    <option value="2">Cash</option>
                </select>
            </div>
        </div>
        <div class="col-12 pt-4 pb-4">
            <button type="submit" class="btn btn-primary form-control">
                Download Report
            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zaito-reports\resources\views/reports/request.blade.php ENDPATH**/ ?>